import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/sp_loader.dart';

class JobAlertsScreen extends StatefulWidget {
  const JobAlertsScreen({super.key});

  @override
  State<JobAlertsScreen> createState() => _JobAlertsScreenState();
}

class _JobAlertsScreenState extends State<JobAlertsScreen> {
  List _jobs = [];
  bool _loading = true;
  String _role = 'Flutter Developer';
  List<String> _availableRoles = [];
  bool _loadingRoles = true;

  @override
  void initState() {
    super.initState();
    _loadRoles();
  }

  Future<void> _loadRoles() async {
    // ✅ FIX: Read SharedPreferences FIRST before any async gap so _role is
    // always initialised from the saved selection, not the hardcoded fallback.
    final prefs = await SharedPreferences.getInstance();
    final savedRole = prefs.getString('target_role') ?? '';
    if (savedRole.isNotEmpty) {
      setState(() => _role = savedRole);
    }

    try {
      final roles = await ApiService.getJobRoles();

      List<String> fetchedRoles = [];
      if (roles is List) {
        fetchedRoles = roles.cast<String>();
      } else if (roles is Map && roles['roles'] is List) {
        fetchedRoles = (roles['roles'] as List).cast<String>();
      }

      // Re-read prefs after await in case they changed
      final latestSaved = prefs.getString('target_role') ?? '';

      setState(() {
        _availableRoles = fetchedRoles;
        if (_availableRoles.contains(latestSaved)) {
          _role = latestSaved;
        } else if (_availableRoles.isNotEmpty) {
          _role = _availableRoles.first;
        }
        _loadingRoles = false;
      });

      await _loadJobs();
    } catch (e) {
      setState(() => _loadingRoles = false);
      await _loadJobs();
    }
  }

  Future<void> _loadJobs() async {
    setState(() => _loading = true);
    try {
      final jobs = await ApiService.getJobs(_role);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('target_role', _role);
      
      setState(() {
        _jobs = jobs;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFF140536),
        foregroundColor: Colors.white,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 36),
            SizedBox(width: 16),
            Text("Job Alerts", style: TextStyle(fontSize: 18)),
          ],
        ),
        actions: [
          Padding(
            padding: EdgeInsets.all(12),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.amber,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  '${_jobs.length} Jobs',
                  style: TextStyle(
                    color: Color(0xFF140536),
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: _loadingRoles
          ? const SpLoader(message: 'Loading roles...')
          : SingleChildScrollView(
              child: Column(
                children: [
                  // Role selector
                  Padding(
                    padding: EdgeInsets.all(16),
                    child: DropdownButtonFormField<String>(
                      value: _role,
                      decoration: InputDecoration(
                        labelText: 'Select Job Role',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        prefixIcon: Icon(Icons.work),
                      ),
                      items: _availableRoles
                          .map((role) => DropdownMenuItem(
                                value: role,
                                child: Text(role),
                              ))
                          .toList(),
                      onChanged: (newRole) {
                        if (newRole != null && newRole != _role) {
                          setState(() => _role = newRole);
                          _loadJobs();
                        }
                      },
                    ),
                  ),

                  // Search count header
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                      'Showing ${_jobs.length} remote jobs for $_role',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
                  SizedBox(height: 12),

                  // Loading shimmer or job list
                  if (_loading)
                    Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        children: List.generate(
                          3,
                          (i) => Container(
                            margin: EdgeInsets.only(bottom: 16),
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 16,
                                  width: 150,
                                  color: Colors.grey.shade400,
                                ),
                                SizedBox(height: 8),
                                Container(
                                  height: 12,
                                  width: 100,
                                  color: Colors.grey.shade400,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                  else if (_jobs.isEmpty)
                    Padding(
                      padding: EdgeInsets.all(24),
                      child: Text("No jobs found for $_role"),
                    )
                  else
                    ListView.builder(
                      padding: EdgeInsets.all(16),
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: _jobs.length,
                      itemBuilder: (context, index) {
                        final job = _jobs[index];
                        final salary = job['salary'];
                        final hasSalary =
                            salary != null && salary != 'Not Specified' && salary.isNotEmpty;

                        return Container(
                          margin: EdgeInsets.only(bottom: 16),
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 6,
                                offset: Offset(0, 3),
                              )
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                job['title'] ?? '',
                                style: TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                job['company_name'] ?? '',
                                style: TextStyle(color: Colors.black54),
                              ),
                              SizedBox(height: 4),
                              Row(
                                children: [
                                  Icon(Icons.location_on,
                                      size: 15, color: Colors.grey),
                                  SizedBox(width: 4),
                                  Expanded(
                                    child: Text(
                                      job['candidate_required_location'] ?? 'Remote',
                                      style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              if (hasSalary) ...[
                                SizedBox(height: 8),
                                Row(
                                  children: [
                                    Icon(Icons.attach_money,
                                        size: 14, color: Colors.green),
                                    SizedBox(width: 4),
                                    Text(
                                      salary,
                                      style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.green,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                              SizedBox(height: 10),
                              Align(
                                alignment: Alignment.centerRight,
                                child: TextButton.icon(
                                  onPressed: () async {
                                    final url = Uri.parse(job['url'] ?? '');
                                    if (await canLaunchUrl(url)) {
                                      launchUrl(
                                        url,
                                        mode: LaunchMode.externalApplication,
                                      );
                                    }
                                  },
                                  icon: Icon(Icons.open_in_new, size: 15),
                                  label: Text("Apply"),
                                  style: TextButton.styleFrom(
                                    foregroundColor: Color(0xFF140536),
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 6,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF140536),
        mini: true,
        onPressed: _loadJobs,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}

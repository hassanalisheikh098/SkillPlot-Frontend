import 'package:flutter/material.dart';

class JobAlertsScreen extends StatelessWidget {
  final List<Map<String, String>> jobAlerts = [
    {
      'title': 'Junior Flutter Developer',
      'company': 'TechVerse Pvt Ltd',
      'location': 'Lahore, Pakistan',
    },
    {
      'title': 'Data Analyst (Remote)',
      'company': 'DataInsight Ltd',
      'location': 'Remote',
    },
    {
      'title': 'Frontend Developer (React)',
      'company': 'DigitalX',
      'location': 'Islamabad, Pakistan',
    },
    {
      'title': 'AI Research Intern',
      'company': 'Innovate AI',
      'location': 'Remote',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA).withOpacity(0.94), // Slightly transparent
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFF140536).withOpacity(0.95), // Reduced opacity
        foregroundColor: Colors.white,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 36),
            SizedBox(width: 16),
            Text("Job Alerts", style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(24),
        itemCount: jobAlerts.length,
        itemBuilder: (context, index) {
          final job = jobAlerts[index];
          return Container(
            margin: EdgeInsets.only(bottom: 16),
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.97), // Card with light opacity
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 6,
                  offset: Offset(0, 3),
                )
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(job['title']!, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                Text(job['company']!, style: TextStyle(color: Colors.black54)),
                SizedBox(height: 2),
                Row(
                  children: [
                    Icon(Icons.location_on, size: 16, color: Colors.grey),
                    SizedBox(width: 4),
                    Text(job['location']!, style: TextStyle(color: Colors.black87)),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

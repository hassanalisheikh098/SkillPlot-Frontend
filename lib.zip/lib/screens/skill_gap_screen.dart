import 'package:flutter/material.dart';
import '../services/api_service.dart';

class SkillGapScreen extends StatefulWidget {
  @override
  _SkillGapScreenState createState() => _SkillGapScreenState();
}

class _SkillGapScreenState extends State<SkillGapScreen> {

  Map<String, dynamic> data = {};
  List<dynamic> jobs = [];
  bool loading = false;

  Future<void> fetchSkillGap() async {

    setState(() {
      loading = true;
    });

    try {
      data = await ApiService.analyzeJobs();

      print("FULL DATA: $data");

      setState(() {
        jobs = data["jobs"] ?? [];
      });

    } catch (e) {
      print("ERROR: $e");
    }

    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),

      appBar: AppBar(
        backgroundColor: Color(0xFF140536),
        title: Text("Skill Gap Analyzer"),
        foregroundColor: Colors.white,
      ),

      // 🔥 FIXED BODY (SCROLL ISSUE SOLVED)
      body: loading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [

                SizedBox(height: 16),

                ElevatedButton(
                  onPressed: fetchSkillGap,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF140536),
                  ),
                  child: Text("Analyze Skill Gap"),
                ),

                SizedBox(height: 10),

                Expanded(
                  child: ListView.builder(
                    physics: BouncingScrollPhysics(), // smooth scroll
                    itemCount: jobs.length,
                    itemBuilder: (context, index) {

                      final job = jobs[index];

                      return Card(
                        margin: EdgeInsets.symmetric(
                          vertical: 8,
                          horizontal: 12,
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Text(
                                job["title"] ?? "",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              SizedBox(height: 6),

                              Text("Company: ${job["company"] ?? ""}"),

                              SizedBox(height: 6),

                              Text(
                                "Match: ${job["match_percentage"] ?? 0}%",
                                style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 6),

                              Text(
                                "Matched Skills:",
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),

                              Text(
                                (job["matched_skills"] ?? []).join(", "),
                                style: TextStyle(color: Colors.red),
                              ),

                              SizedBox(height: 6),

                              Text(
                                "Missing Skills:",
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),

                              Text(
                                (job["missing_skills"] ?? []).join(", "),
                                style: TextStyle(color: Colors.red),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
    );
  }
}
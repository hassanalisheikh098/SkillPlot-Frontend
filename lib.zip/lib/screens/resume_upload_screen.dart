import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;

class ResumeUploadScreen extends StatefulWidget {
  @override
  _ResumeUploadScreenState createState() => _ResumeUploadScreenState();
}

class _ResumeUploadScreenState extends State<ResumeUploadScreen> {

  // ✅ STATIC VARIABLES
  static String? fileName;
  static File? selectedFile;

  // 📁 Function to pick + upload resume
  Future<void> pickResume() async {

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx'],
    );

    if (result != null && result.files.single.path != null) {

      // ✅ SAVE FILE
      selectedFile = File(result.files.single.path!);

      setState(() {
        fileName = result.files.single.name;
      });

      try {

        var request = http.MultipartRequest(
          'POST',
          Uri.parse("http://10.0.2.2:5000/upload-resume"),
        );

        request.files.add(
          await http.MultipartFile.fromPath(
            'file',
            selectedFile!.path,
          ),
        );

        request.fields['user_id'] = "1";

        var response = await request.send();

        if (response.statusCode == 200) {

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                "Resume uploaded successfully! ✅",
              ),
            ),
          );

        } else {

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                "Please upload a valid Resume/CV in PDF format only.",
              ),
            ),
          );
        }

      } catch (e) {

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Error: $e"),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Color(0xFFF4F6FA),

      appBar: AppBar(

        title: Row(
          children: [

            Image.asset(
              'assets/images/background.png',
              width: 32,
            ),

            SizedBox(width: 12),

            Text("Upload Resume"),
          ],
        ),

        backgroundColor: Color(0xFF140536),
        foregroundColor: Colors.white,
      ),

      body: Padding(

        padding: const EdgeInsets.all(24.0),

        child: Container(

          padding: EdgeInsets.all(24),

          decoration: BoxDecoration(

            color: Colors.white,

            borderRadius: BorderRadius.circular(16),

            boxShadow: [

              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),

          child: Column(

            crossAxisAlignment: CrossAxisAlignment.start,

            children: [

              Text(
                "Let’s get started with your resume",

                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
              ),

              SizedBox(height: 16),

              Text(
                "Upload your latest resume. We’ll analyze it and help you improve it.",

                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black54,
                ),
              ),

              SizedBox(height: 32),

              // 📎 Upload Button
              GestureDetector(

                onTap: pickResume,

                child: Container(

                  padding: EdgeInsets.symmetric(vertical: 18),

                  width: double.infinity,

                  decoration: BoxDecoration(
                    color: Color(0xFF4B0082),
                    borderRadius: BorderRadius.circular(8),
                  ),

                  child: Center(

                    child: Text(
                      "Choose & Upload Resume",

                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),

              // ✅ FILE NAME SHOW
              if (fileName != null) ...[

                SizedBox(height: 24),

                Container(

                  padding: EdgeInsets.all(14),

                  width: double.infinity,

                  decoration: BoxDecoration(
                    color: Colors.indigo.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Colors.indigo.shade200,
                    ),
                  ),

                  child: Row(

                    children: [

                      Icon(
                        Icons.description,
                        color: Colors.indigo,
                      ),

                      SizedBox(width: 10),

                      Expanded(
                        child: Text(
                          fileName!,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
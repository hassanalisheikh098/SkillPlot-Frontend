import 'package:flutter/material.dart';
import 'package:sp_app/screens/learning_dashboard_screen.dart';
import 'resume_upload_screen.dart';
import 'skill_gap_screen.dart';
import 'course_recommendation_screen.dart';
import 'course_completion_screen.dart';
import 'chatbot_screen.dart';
import 'job_alerts_screen.dart';
import 'resume_builder_screen.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF140536).withOpacity(0.85),
      appBar: AppBar(
        backgroundColor: Color(0xFF140536).withOpacity(0.85),
        elevation: 0,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 50),
            SizedBox(width: 50),
            Text(
              'SkillPilot',
              style: TextStyle(fontSize: 18, color: Colors.white),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Center(
              child: Text(
                "Options",
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.3, // ✅ FIXED (was 4.8)
          children: [
            _buildTile(
              context,
              Icons.upload_file,
              "Upload Resume",
              ResumeUploadScreen(),
            ),
            _buildTile(
              context,
              Icons.analytics,
              "Skill Gap Analysis",
              SkillGapScreen(),
            ),
            _buildTile(
              context,
              Icons.school,
              "Course Recommendations",
              CourseRecommendationScreen(),
            ),
            _buildTile(
              context,
              Icons.check_circle,
              "Mark Completion",
              CourseCompletionScreen(),
            ),
            _buildTile(context, Icons.route, "ChatBot", ChatbotScreen()),
            _buildTile(
              context,
              Icons.leaderboard,
              "Learning Dashboard",
              LearningDashboardScreen(),
            ),
            _buildTile(context, Icons.work, "Job Alerts", JobAlertsScreen()),
            _buildTile(
              context,
              Icons.description,
              "Resume Builder",
              ResumeBuilderScreen(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTile(
    BuildContext context,
    IconData icon,
    String label,
    Widget screen,
  ) {
    return GestureDetector(
      onTap: () =>
          Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
      child: Container(
        decoration: BoxDecoration(
          color: Color(0xFF1F1B3A),
          borderRadius: BorderRadius.circular(16),
        ),
        padding: EdgeInsets.symmetric(
          vertical: 12,
          horizontal: 8,
        ), // ✅ adjusted
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.deepPurpleAccent[100], size: 30),
            SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 2, // ✅ overflow safe
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: Colors.white, fontSize: 13.5),
            ),
          ],
        ),
      ),
    );
  }
}

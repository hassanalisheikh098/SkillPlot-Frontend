import 'package:flutter/material.dart';

class CourseRecommendationScreen extends StatelessWidget {
  final List<Map<String, String>> recommendedCourses = [
    {
      'title': 'Data Analysis with Python',
      'platform': 'Coursera',
    },
    {
      'title': 'Machine Learning A-Z',
      'platform': 'Udemy',
    },
    {
      'title': 'SQL for Data Science',
      'platform': 'edX',
    },
    {
      'title': 'Effective Communication Skills',
      'platform': 'LinkedIn Learning',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF140536).withOpacity(0.85), // ✅ Background with opacity
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFF140536).withOpacity(0.85), // ✅ AppBar with opacity
        foregroundColor: Colors.white,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 36),
            SizedBox(width: 16),
            Text("Recommended Courses"),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Container(
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Courses Just For You",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
              ),
              SizedBox(height: 16),
              Text(
                "These courses can help you fill the skill gaps for your dream job:",
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
              SizedBox(height: 24),
              Expanded(
                child: ListView.builder(
                  itemCount: recommendedCourses.length,
                  itemBuilder: (context, index) {
                    final course = recommendedCourses[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: ListTile(
                        leading: Icon(Icons.school, color: Color(0xFF140536)),
                        title: Text(course['title']!),
                        subtitle: Text("Platform: ${course['platform']}"),
                        tileColor: Color(0xFFF1E6FF),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

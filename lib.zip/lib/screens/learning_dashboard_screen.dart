import 'package:flutter/material.dart';

class LearningDashboardScreen extends StatelessWidget {
  final List<Map<String, dynamic>> progressList = [
    {
      'title': 'Data Analysis with Python',
      'progress': 0.75,
    },
    {
      'title': 'Machine Learning A-Z',
      'progress': 0.55,
    },
    {
      'title': 'SQL for Data Science',
      'progress': 0.90,
    },
    {
      'title': 'Effective Communication Skills',
      'progress': 0.40,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),
      appBar: AppBar(
        backgroundColor: Color(0xFF140536).withOpacity(0.9), // Dark Purple with opacity
        elevation: 0,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 36),
            SizedBox(width: 16),
            Text("Learning Dashboard", style: TextStyle(fontSize: 18)),
          ],
        ),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Container(
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Track your learning journey",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
              ),
              SizedBox(height: 16),
              Text(
                "Monitor your course progress and stay motivated.",
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
              SizedBox(height: 24),
              Expanded(
                child: ListView.builder(
                  itemCount: progressList.length,
                  itemBuilder: (context, index) {
                    final course = progressList[index];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          course['title'],
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                        SizedBox(height: 8),
                        LinearProgressIndicator(
                          value: course['progress'],
                          backgroundColor: Colors.grey[300],
                          color: Color(0xFF4B0082), // Dark Purple
                          minHeight: 10,
                        ),
                        SizedBox(height: 20),
                      ],
                    );
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

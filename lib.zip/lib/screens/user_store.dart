import 'package:shared_preferences/shared_preferences.dart';

class UserStore {
  // Load all users from SharedPreferences
  static Future<Map<String, String>> loadUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final Map<String, String> users = {};
    for (var key in prefs.getKeys()) {
      users[key] = prefs.getString(key) ?? '';
    }
    return users;
  }

  // Save a user
  static Future<void> addUser(String email, String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(email, password);
  }

  // Update password
  static Future<void> updatePassword(String email, String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(email, password);
  }

  // Check login
  static Future<bool> validateUser(String email, String password) async {
    final prefs = await SharedPreferences.getInstance();
    final storedPassword = prefs.getString(email);
    if (storedPassword == null) return false;
    return storedPassword == password;
  }

  // Check if user exists
  static Future<bool> userExists(String email) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey(email);
  }
}

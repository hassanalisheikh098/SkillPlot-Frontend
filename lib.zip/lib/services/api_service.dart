import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;

class ApiService {
  static const baseUrl = "http://10.0.2.2:5000";

  // =========================
  // GET ALL JOBS
  // =========================
  static Future<List<dynamic>> getJobs() async {
    final url = Uri.parse("$baseUrl/jobs");

    try {
      final response = await http.get(url).timeout(Duration(seconds: 60));

      log("GET JOBS STATUS: ${response.statusCode}");
      log("GET JOBS BODY: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is List) {
          return data;
        } else {
          throw Exception("Invalid response format: Expected List");
        }
      } else {
        throw Exception("GET JOBS FAILED: ${response.statusCode}");
      }
    } catch (e) {
      log("GET JOBS EXCEPTION: $e");
      rethrow;
    }
  }

  // =========================
  // ANALYZE JOBS
  // =========================
  static Future<Map<String, dynamic>> analyzeJobs() async {
    final url = Uri.parse("$baseUrl/analyze-jobs");

    try {
      final response = await http.get(url);

      log("ANALYZE STATUS: ${response.statusCode}");
      log("ANALYZE BODY: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is Map<String, dynamic>) {
          return data;
        } else {
          throw Exception("Invalid response format: Expected Map");
        }
      } else {
        throw Exception("ANALYZE FAILED: ${response.statusCode}");
      }
    } catch (e) {
      log("ANALYZE EXCEPTION: $e");
      rethrow;
    }
  }

  // =========================
  // SINGLE JOB
  // =========================
  static Future<Map<String, dynamic>> analyzeSingleJob(int index) async {
    final url = Uri.parse("$baseUrl/analyze/$index");

    try {
      final response = await http.get(url);

      log("SINGLE JOB STATUS: ${response.statusCode}");
      log("SINGLE JOB BODY: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is Map<String, dynamic>) {
          return data;
        } else {
          throw Exception("Invalid response format: Expected Map");
        }
      } else {
        throw Exception("SINGLE JOB FAILED: ${response.statusCode}");
      }
    } catch (e) {
      log("SINGLE JOB EXCEPTION: $e");
      rethrow;
    }
  }
}
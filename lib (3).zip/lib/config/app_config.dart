class AppConfig {
  static const bool isProduction =
      bool.fromEnvironment('PRODUCTION', defaultValue: false);

  static String get apiBaseUrl {
    if (isProduction) {
      return const String.fromEnvironment('API_BASE_URL',
          defaultValue: 'https://skillpilot-api.onrender.com/api/v1');
    }
    // Android emulator default
    return 'http://10.0.2.2:8000/api/v1';
  }

  static String get supabaseUrl {
    return const String.fromEnvironment('SUPABASE_URL',
        defaultValue: 'https://gmrayhnwhivcdvzhixdj.supabase.co');
  }

  static String get supabaseAnonKey {
    return const String.fromEnvironment('SUPABASE_ANON_KEY',
        defaultValue: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...');
  }
}
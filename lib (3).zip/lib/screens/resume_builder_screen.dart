import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ResumeBuilderScreen extends StatefulWidget {
  const ResumeBuilderScreen({super.key});

  @override
  _ResumeBuilderScreenState createState() => _ResumeBuilderScreenState();
}

class _ResumeBuilderScreenState extends State<ResumeBuilderScreen> {
  final _formKey = GlobalKey<FormState>();

  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _summaryController = TextEditingController();
  final _skillsController = TextEditingController();
  final _experienceController = TextEditingController();
  final _educationController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSavedResume();
  }

  Future _loadSavedResume() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('saved_resume');
    if (saved != null) {
      final data = jsonDecode(saved) as Map;
      setState(() {
        _fullNameController.text = data['full_name'] ?? '';
        _emailController.text = data['email'] ?? '';
        _phoneController.text = data['phone'] ?? '';
        _summaryController.text = data['summary'] ?? '';
        _skillsController.text = data['skills'] ?? '';
        _experienceController.text = data['experience'] ?? '';
        _educationController.text = data['education'] ?? '';
      });
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _summaryController.dispose();
    _skillsController.dispose();
    _experienceController.dispose();
    _educationController.dispose();
    super.dispose();
  }

  Future _saveResume() async {
    if (_formKey.currentState!.validate()) {
      final resumeData = {
        'full_name': _fullNameController.text,
        'email': _emailController.text,
        'phone': _phoneController.text,
        'summary': _summaryController.text,
        'skills': _skillsController.text,
        'experience': _experienceController.text,
        'education': _educationController.text,
      };
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('saved_resume', jsonEncode(resumeData));

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Resume saved! ✅"),
            backgroundColor: Color(0xFF4B0082),
          ),
        );
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => _ResumePreviewScreen(data: resumeData),
          ),
        );
      }
    }
  }

  Map _currentData() => {
        'full_name': _fullNameController.text,
        'email': _emailController.text,
        'phone': _phoneController.text,
        'summary': _summaryController.text,
        'skills': _skillsController.text,
        'experience': _experienceController.text,
        'education': _educationController.text,
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 32),
            SizedBox(width: 12),
            Text("Build Your Resume"),
          ],
        ),
        backgroundColor: Color(0xFF140536).withValues(alpha: 0.9), // Updated opacity here
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionTitle("Personal Information"),
              _buildTextField("Full Name", _fullNameController),
              _buildTextField("Email", _emailController),
              _buildTextField("Phone", _phoneController),

              _buildSectionTitle("Professional Summary"),
              _buildTextArea(_summaryController),

              _buildSectionTitle("Skills"),
              _buildTextArea(_skillsController),

              _buildSectionTitle("Experience"),
              _buildTextArea(_experienceController),

              _buildSectionTitle("Education"),
              _buildTextArea(_educationController),

              SizedBox(height: 30),
              ElevatedButton.icon(
                icon: Icon(Icons.save),
                label: Text("Save Resume"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF140536),
                  foregroundColor: Colors.white,
                  minimumSize: Size(double.infinity, 48),
                ),
                onPressed: _saveResume,
              ),
              SizedBox(height: 12),
              OutlinedButton.icon(
                icon: Icon(Icons.preview),
                label: Text("Preview Resume"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Color(0xFF140536),
                  side: BorderSide(color: Color(0xFF140536)),
                  minimumSize: Size(double.infinity, 48),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => _ResumePreviewScreen(data: _currentData()),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Color(0xFF140536),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        validator: (value) => value!.isEmpty ? "Required" : null,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
    );
  }

  Widget _buildTextArea(TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        maxLines: 4,
        validator: (value) => value!.isEmpty ? "Required" : null,
        decoration: InputDecoration(
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
    );
  }
}

class _ResumePreviewScreen extends StatelessWidget {
  final Map data;
  const _ResumePreviewScreen({required this.data});

  Widget _section(String title, String content) {
    if (content.trim().isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 16),
        Text(
          title,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: Color(0xFF140536),
            letterSpacing: 0.8,
          ),
        ),
        const Divider(color: Color(0xFF140536), thickness: 1),
        const SizedBox(height: 6),
        Text(
          content,
          style: const TextStyle(fontSize: 13, color: Colors.black87, height: 1.5),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),
      appBar: AppBar(
        title: const Text("Resume Preview"),
        backgroundColor: Color(0xFF140536),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8)],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                data['full_name'] ?? '',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF140536),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${data['email'] ?? ''}  •  ${data['phone'] ?? ''}',
                style: const TextStyle(fontSize: 13, color: Colors.black54),
              ),
              _section("PROFESSIONAL SUMMARY", data['summary'] ?? ''),
              _section("SKILLS", data['skills'] ?? ''),
              _section("EXPERIENCE", data['experience'] ?? ''),
              _section("EDUCATION", data['education'] ?? ''),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://gmrayhnwhivcdvzhixdj.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdtcmF5aG53aGl2Y2R2emhpeGRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA2NzI4OTgsImV4cCI6MjA5NjI0ODg5OH0.z8Ktu87dqGfXLDLKb6NauOpFHLN6bKoELLjVg1k6wog',
  );
  runApp(SkillPilotApp());
}

class SkillPilotApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SkillPilot',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFF4B0082),
        scaffoldBackgroundColor: Colors.white,
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: SplashScreen(),
    );
  }
}

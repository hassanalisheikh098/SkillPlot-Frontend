import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LearningDashboardScreen extends StatefulWidget {
  const LearningDashboardScreen({super.key});

  @override
  State<LearningDashboardScreen> createState() => _LearningDashboardScreenState();
}

class _LearningDashboardScreenState extends State<LearningDashboardScreen> {
  int _totalXp = 0;
  List _badges = ['Beginner'];
  int _completedCourses = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future _loadProgress() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString('user_id') ?? '';
      if (userId.isNotEmpty) {
        final result = await ApiService.getProgress(userId);
        setState(() {
          _totalXp = result['total_xp'] ?? 0;
          _badges = List.from(result['badges'] ?? ['Beginner']);
          _completedCourses = result['completed_courses'] ?? 0;
        });
      }
    } catch (_) {}
    finally { setState(() => _loading = false); }
  }

  Widget _statCard(String label, String value) {
    return Container(
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Color(0xFFF4F4F4),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF140536),
            ),
          ),
          SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),
      appBar: AppBar(
        backgroundColor: Color(0xFF140536).withValues(alpha: 0.9),
        elevation: 0,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 36),
            SizedBox(width: 16),
            Text("Learning Dashboard", style: TextStyle(fontSize: 18)),
          ],
        ),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Container(
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: _loading
              ? Center(child: CircularProgressIndicator())
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Track your learning journey",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF333333),
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      "XP, badges and completed courses.",
                      style: TextStyle(fontSize: 14, color: Colors.black54),
                    ),
                    SizedBox(height: 24),

                    Center(
                      child: Text(
                        "$_totalXp XP",
                        style: TextStyle(
                          fontSize: 44,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF4B0082),
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: (_totalXp % 500) / 500,
                      backgroundColor: Colors.grey[300],
                      color: Color(0xFF4B0082),
                      minHeight: 10,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    SizedBox(height: 4),
                    Text(
                      "Next badge at ${((_totalXp ~/ 500) + 1) * 500} XP",
                      style: TextStyle(fontSize: 12, color: Colors.black45),
                    ),
                    SizedBox(height: 20),

                    Row(
                      children: [
                        Expanded(child: _statCard("Courses Done", "$_completedCourses")),
                        SizedBox(width: 12),
                        Expanded(child: _statCard("Current Level", _badges.last)),
                      ],
                    ),
                    SizedBox(height: 20),

                    Text(
                      "Your Badges",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                    SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: _badges
                          .map(
                            (badge) => Chip(
                              avatar: Icon(
                                Icons.star,
                                size: 16,
                                color: badge == 'Beginner' ? Colors.grey : Colors.amber,
                              ),
                              label: Text(badge, style: TextStyle(fontSize: 12)),
                              backgroundColor: badge == 'Beginner'
                                  ? Color(0xFFE0E0E0)
                                  : Color(0xFFFFF9C4),
                            ),
                          )
                          .toList(),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

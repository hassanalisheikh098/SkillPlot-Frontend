import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RoadmapScreen extends StatefulWidget {
  @override
  _RoadmapScreenState createState() => _RoadmapScreenState();
}

class _RoadmapScreenState extends State<RoadmapScreen> {
  List _steps = [];
  bool _loading = false;
  String _targetRole = 'Software Developer';
  List<String> _missingSkills = [];

  @override
  void initState() {
    super.initState();
    _loadAndGenerate();
  }

  Future _loadAndGenerate() async {
    final prefs = await SharedPreferences.getInstance();
    _targetRole = prefs.getString('target_role') ?? 'Software Developer';
    final s = prefs.getString('missing_skills') ?? '';
    _missingSkills = s.isEmpty ? [] : s.split(',');
    await _generate();
  }

  Future _generate() async {
    setState(() => _loading = true);
    try {
      final result = await ApiService.generateRoadmap(_targetRole, _missingSkills);
      setState(() {
        _steps = result['steps'] ?? [];
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to generate roadmap. Try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),
      appBar: AppBar(
        backgroundColor: Color(0xFF140536),
        foregroundColor: Colors.white,
        title: Row(children: [
          Image.asset('assets/images/background.png', width: 32),
          SizedBox(width: 12),
          Text("Career Roadmap"),
        ]),
      ),
      body: _loading
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Color(0xFF140536)),
                  SizedBox(height: 16),
                  Text(
                    "Generating your AI roadmap...",
                    style: TextStyle(color: Colors.black54),
                  ),
                ],
              ),
            )
          : _steps.isEmpty
              ? Center(child: Text("No roadmap yet. Run Skill Gap Analysis first."))
              : ListView.builder(
                  padding: EdgeInsets.all(16),
                  itemCount: _steps.length,
                  itemBuilder: (context, index) {
                    final step = _steps[index];
                    return Container(
                      margin: EdgeInsets.only(bottom: 16),
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(color: Colors.black12, blurRadius: 6),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: Color(0xFF140536),
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                '${step['step_number'] ?? index + 1}',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  step['title'] ?? '',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 6),
                                Text(
                                  step['description'] ?? '',
                                  style: TextStyle(
                                    color: Colors.black54,
                                    fontSize: 13,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Row(
                                  children: [
                                    Icon(Icons.schedule, size: 14, color: Colors.grey),
                                    SizedBox(width: 4),
                                    Text(
                                      "~${step['estimated_weeks']} weeks",
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 8),
                                Wrap(
                                  spacing: 6,
                                  runSpacing: 4,
                                  children: List.from(step['resources'] ?? [])
                                      .map(
                                        (r) => Chip(
                                          label: Text(
                                            r.length > 30 ? '${r.substring(0, 30)}…' : r,
                                            style: TextStyle(fontSize: 11),
                                          ),
                                          backgroundColor: Color(0xFFE4D6FF),
                                          labelStyle:
                                              TextStyle(color: Color(0xFF4B0082)),
                                          padding: EdgeInsets.zero,
                                          materialTapTargetSize:
                                              MaterialTapTargetSize.shrinkWrap,
                                        ),
                                      )
                                      .toList(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Color(0xFF140536),
        icon: Icon(Icons.refresh, color: Colors.white),
        label: Text("Regenerate", style: TextStyle(color: Colors.white)),
        onPressed: _generate,
      ),
    );
  }
}

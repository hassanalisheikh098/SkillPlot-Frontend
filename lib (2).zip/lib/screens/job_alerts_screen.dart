import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class JobAlertsScreen extends StatefulWidget {
  const JobAlertsScreen({super.key});

  @override
  State<JobAlertsScreen> createState() => _JobAlertsScreenState();
}

class _JobAlertsScreenState extends State<JobAlertsScreen> {
  List _jobs = [];
  bool _loading = true;
  String _role = 'Flutter Developer';

  @override
  void initState() {
    super.initState();
    _loadJobs();
  }

  Future _loadJobs() async {
    setState(() => _loading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      _role = prefs.getString('target_role') ?? 'Flutter Developer';
      final jobs = await ApiService.getJobs(_role);
      setState(() {
        _jobs = jobs;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF4F6FA),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFF140536),
        foregroundColor: Colors.white,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 36),
            SizedBox(width: 16),
            Text("Job Alerts", style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator())
          : _jobs.isEmpty
              ? Center(child: Text("No jobs found for $_role"))
              : ListView.builder(
                  padding: EdgeInsets.all(24),
                  itemCount: _jobs.length,
                  itemBuilder: (context, index) {
                    final job = _jobs[index];
                    return Container(
                      margin: EdgeInsets.only(bottom: 16),
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 6,
                            offset: Offset(0, 3),
                          )
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            job['title'] ?? '',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            job['company_name'] ?? '',
                            style: TextStyle(color: Colors.black54),
                          ),
                          SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Icons.location_on, size: 15, color: Colors.grey),
                              SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  job['candidate_required_location'] ?? 'Remote',
                                  style: TextStyle(
                                    color: Colors.black87,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton.icon(
                              onPressed: () async {
                                final url = Uri.parse(job['url'] ?? '');
                                if (await canLaunchUrl(url)) {
                                  launchUrl(
                                    url,
                                    mode: LaunchMode.externalApplication,
                                  );
                                }
                              },
                              icon: Icon(Icons.open_in_new, size: 15),
                              label: Text("Apply"),
                              style: TextButton.styleFrom(
                                foregroundColor: Color(0xFF140536),
                                padding: EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 6,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF140536),
        mini: true,
        onPressed: _loadJobs,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}

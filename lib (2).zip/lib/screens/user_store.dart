import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserStore {
  static SupabaseClient get _client => Supabase.instance.client;

  // Sign up new user via Supabase Auth
  static Future<bool> addUser(String email, String password) async {
    try {
      final res = await _client.auth.signUp(email: email, password: password);
      return res.user != null;
    } catch (e) {
      return false;
    }
  }

  // Login via Supabase Auth - saves user_id to SharedPrefs for other screens
  static Future<bool> validateUser(String email, String password) async {
    try {
      final res = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );
      if (res.session != null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('user_id', res.user?.id ?? '');
        await prefs.setString('user_email', email);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // Logout and clear local data
  static Future<void> logout() async {
    await _client.auth.signOut();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  // Not used anymore but kept so nothing breaks
  static Future<void> updatePassword(String email, String password) async {}
  static Future<bool> userExists(String email) async => false;
  static Future<Map<String, String>> loadUsers() async => {};

  // Convenience getters
  static bool get isLoggedIn => _client.auth.currentUser != null;
  static String? get currentUserId => _client.auth.currentUser?.id;
  static String? get currentUserEmail => _client.auth.currentUser?.email;
}

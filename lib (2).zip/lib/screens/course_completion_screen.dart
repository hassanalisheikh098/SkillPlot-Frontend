import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CourseCompletionScreen extends StatefulWidget {
  const CourseCompletionScreen({super.key});

  @override
  _CourseCompletionScreenState createState() => _CourseCompletionScreenState();
}

class _CourseCompletionScreenState extends State<CourseCompletionScreen> {
  final List<Map<String, dynamic>> courses = [
    {'title': 'Data Analysis with Python', 'completed': false},
    {'title': 'Machine Learning A-Z', 'completed': false},
    {'title': 'SQL for Data Science', 'completed': false},
    {'title': 'Effective Communication Skills', 'completed': false},
  ];

  Future toggleCompletion(int index) async {
    setState(() {
      courses[index]['completed'] = !courses[index]['completed'];
    });

    // Only award XP when marking as complete (not when unchecking)
    if (courses[index]['completed'] == true) {
      try {
        final prefs = await SharedPreferences.getInstance();
        final userId = prefs.getString('user_id') ?? '';
        if (userId.isNotEmpty) {
          final result = await ApiService.awardXP(userId, 'course_completed');
          final xp = result['action_xp'] ?? 100;
          final newBadges = List.from(result['new_badges'] ?? []);
          String msg = "+$xp XP earned! 🎉";
          if (newBadges.isNotEmpty) msg += "  New badge: ${newBadges.first} 🏅";
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(msg),
              backgroundColor: Color(0xFF4B0082),
              duration: Duration(seconds: 3),
            ),
          );
        }
      } catch (e) {
        // Silent fail — completion is still recorded locally
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF140536).withValues(alpha: 0.85), // ✅ Background with opacity
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFF140536).withValues(alpha: 0.85), // ✅ AppBar with opacity
        foregroundColor: Colors.white,
        title: Row(
          children: [
            Image.asset('assets/images/background.png', width: 36),
            SizedBox(width: 16),
            Text("Mark Course Completion"),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Container(
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Completed Your Courses?",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
              ),
              SizedBox(height: 16),
              Text(
                "Mark any course below that you’ve successfully completed.",
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
              SizedBox(height: 24),
              Expanded(
                child: ListView.builder(
                  itemCount: courses.length,
                  itemBuilder: (context, index) {
                    final course = courses[index];
                    return CheckboxListTile(
                      title: Text(course['title']),
                      value: course['completed'],
                      activeColor: Color(0xFF140536), // Dark purple
                      onChanged: (_) => toggleCompletion(index),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

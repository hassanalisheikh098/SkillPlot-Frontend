import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ResumeUploadScreen extends StatefulWidget {
  const ResumeUploadScreen({super.key});

  @override
  _ResumeUploadScreenState createState() => _ResumeUploadScreenState();
}

class _ResumeUploadScreenState extends State<ResumeUploadScreen> {

  // ✅ STATIC VARIABLES
  static String? fileName;
  static File? selectedFile;
  Uint8List? selectedBytes;
  List _extractedSkills = [];

  // 📁 Function to pick + upload resume
  Future<void> pickResume() async {

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx'],
    );

    if (result != null) {
      final pickedFile = result.files.single;

      // ✅ SAVE FILE
      fileName = pickedFile.name;
      selectedBytes = pickedFile.bytes;
      if (!kIsWeb && pickedFile.path != null) {
        selectedFile = File(pickedFile.path!);
      }

      setState(() {});

      try {
        final prefs = await SharedPreferences.getInstance();
        final userId = prefs.getString('user_id') ?? '';

        final result = await ApiService.uploadResume(
          file: selectedFile,
          bytes: selectedBytes,
          filename: fileName!,
          userId: userId,
        );
        final skills = List.from(result['extracted_skills'] ?? []);

        // Save skills for skill gap screen to use
        await prefs.setString('extracted_skills', skills.join(','));

        setState(() {
          _extractedSkills = skills;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Resume uploaded! Found ${skills.length} skills ✅"),
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Upload error: $e")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Color(0xFFF4F6FA),

      appBar: AppBar(

        title: Row(
          children: [

            Image.asset(
              'assets/images/background.png',
              width: 32,
            ),

            SizedBox(width: 12),

            Text("Upload Resume"),
          ],
        ),

        backgroundColor: Color(0xFF140536),
        foregroundColor: Colors.white,
      ),

      body: Padding(

        padding: const EdgeInsets.all(24.0),

        child: Container(

          padding: EdgeInsets.all(24),

          decoration: BoxDecoration(

            color: Colors.white,

            borderRadius: BorderRadius.circular(16),

            boxShadow: [

              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),

          child: Column(

            crossAxisAlignment: CrossAxisAlignment.start,

            children: [

              Text(
                "Let’s get started with your resume",

                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
              ),

              SizedBox(height: 16),

              Text(
                "Upload your latest resume. We’ll analyze it and help you improve it.",

                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black54,
                ),
              ),

              SizedBox(height: 32),

              // 📎 Upload Button
              GestureDetector(

                onTap: pickResume,

                child: Container(

                  padding: EdgeInsets.symmetric(vertical: 18),

                  width: double.infinity,

                  decoration: BoxDecoration(
                    color: Color(0xFF4B0082),
                    borderRadius: BorderRadius.circular(8),
                  ),

                  child: Center(

                    child: Text(
                      "Choose & Upload Resume",

                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),

              // ✅ FILE NAME SHOW
              if (fileName != null) ...[

                SizedBox(height: 24),

                Container(

                  padding: EdgeInsets.all(14),

                  width: double.infinity,

                  decoration: BoxDecoration(
                    color: Colors.indigo.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Colors.indigo.shade200,
                    ),
                  ),

                  child: Row(

                    children: [

                      Icon(
                        Icons.description,
                        color: Colors.indigo,
                      ),

                      SizedBox(width: 10),

                      Expanded(
                        child: Text(
                          fileName!,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              if (_extractedSkills.isNotEmpty) ...[
                SizedBox(height: 20),
                Text(
                  "Skills Detected (${_extractedSkills.length})",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: _extractedSkills
                      .map((skill) => Chip(
                            label: Text(skill, style: TextStyle(fontSize: 12)),
                            backgroundColor: Color(0xFFE4D6FF),
                            labelStyle: TextStyle(color: Color(0xFF4B0082)),
                          ))
                      .toList(),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}